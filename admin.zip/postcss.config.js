const rtl = require("postcss-rtl");

module.exports = {
    plugins: [rtl()]
};
